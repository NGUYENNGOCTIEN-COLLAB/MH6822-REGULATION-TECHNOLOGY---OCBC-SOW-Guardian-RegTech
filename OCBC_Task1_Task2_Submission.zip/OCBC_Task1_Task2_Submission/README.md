Name: NGUYEN NGOC TIEN
Matriculation ID: M2506667B
Email: NGOCTIEN001@E.NTU.EDU.SG

Data collaboration: None. Synthetic data was created individually for this submission.



\## What this tool does



The tool is a governance layer for AI-assisted source-of-wealth review. It checks whether AI-generated source-of-wealth narratives are supported by evidence, whether human reviewers are exercising real judgment, and whether the right Singapore or US regulatory logic is active.



\## What this tool does not do



The tool does not make final legal determinations, approve customers automatically, file suspicious transaction or suspicious activity reports automatically, replace relationship managers or compliance officers, perform full AML transaction monitoring, or claim that a case is simply "MAS compliant" or "US compliant".



\## Data note



The dataset in `data/synthetic\_sow\_cases.csv` is fully synthetic. It contains simulated KYC/source-of-wealth cases to demonstrate how the architecture would process evidence sufficiency, contradiction counts, human challenge, jurisdictional conflicts, and model drift. It does not contain real OCBC, Bank of Singapore, or customer data.





